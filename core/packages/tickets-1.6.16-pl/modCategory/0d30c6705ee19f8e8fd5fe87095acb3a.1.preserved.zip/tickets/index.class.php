<?php

class IndexManagerController extends modExtraManagerController {

	/**
	 * @return string
	 */
	public static function getDefaultController() {
		return 'home';
	}

}